package battingaverage;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ArrayListRunner {

	static Scanner scan = new Scanner(System.in);
	static ArrayListTeam liberty = new ArrayListTeam();

	public static void main(String[] args) {

		String txt = scan.nextLine();
		File file = new File(txt);
		String path = "C:\\Users\\158850\\eclipse-workspace\\APCS\\" + txt;
		try {
			scan = new Scanner(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int p = scan.nextInt();
		scan.nextLine();

		// Team liberty = new Team(p);
		String content = "";
//		try {
//			content = readFile(path, StandardCharsets.UTF_8);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		ArrayListTeam liberty = new ArrayListTeam();
		for (int e = 0; e < p; e++) {
			String[] words = scan.nextLine().split(" ");

//			for (int i = 0; i < words.length - 1; i++) {
//				System.out.println((words[i]));
//				if (i == 0) {
//					continue;
//				} else {
//					int foo = Integer.parseInt(words[i + 1]);
			System.out.println(words[3]);
			liberty.addPlayer(new Player(words[0], Integer.parseInt(words[1]), Integer.parseInt(words[2]),
					Integer.parseInt(words[3])));
		}
		liberty.printTeamStats();
	}

//			if (i == 0) {
//				continue;
//			} else {
//				int foo = Integer.parseInt(words[i + 1]);
//				liberty.players.set(0, new Player(words[i], foo));
//			}
}
