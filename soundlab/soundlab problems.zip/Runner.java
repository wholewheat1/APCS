package soundlab;

public class Runner {
	static SoundLabProbs lab = new SoundLabProbs();

	public static void main(String args[]) {
		int nums[] = { 12, 3, 3, 5, 18, 3, 2, 4 };
		int value = 3;
		int start = 0;
		System.out.println(lab.lastIndexOf(nums, value));
		System.out.println(lab.range(nums));
		System.out.println(lab.minDifference(nums, 1));
	}
}
