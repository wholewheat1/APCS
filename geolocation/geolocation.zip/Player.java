package geolocation;

public class Player {
	static String name;
	static int number;

	Player() {
		name = "Default";
		number = -1;
	}

	Player(String name, int number) {
		Player.name = name;
		Player.number = number;
	}

	String playerInfo() {
		return "Player: " + name + ", #" + number;

	}
}
